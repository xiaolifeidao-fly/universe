#!/bin/sh
set -eu

APP_NAME="manager"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PID_FILE="$SCRIPT_DIR/$APP_NAME.pid"

if [ ! -f "$PID_FILE" ]; then
  echo "$APP_NAME is not running"
  exit 0
fi

PID="$(cat "$PID_FILE")"
if [ -n "$PID" ] && kill -0 "$PID" 2>/dev/null; then
  kill "$PID"
  echo "$APP_NAME stopped, pid: $PID"
else
  echo "$APP_NAME pid file exists, but process is not running"
fi

rm -f "$PID_FILE"
